#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "image.h"

ImagePPM *readPPM(char *filename)
{

	return NULL;
}

int writePPM(ImagePPM *pImagePPM, char *filename)
{

	return 1;
}

ImagePPM *rotatePPM(ImagePPM *pImagePPM)
{

	return NULL;
}

ImagePPM *flipPPM(ImagePPM *pImagePPM)
{

    return NULL;
}

ImagePPM *enlargePPM(ImagePPM *pImagePPM)
{

    return NULL;
}

ImagePPM *shrinkPPM(ImagePPM *pImagePPM)
{

    return NULL;
}

ImagePPM *invertPPM(ImagePPM *pImagePPM)
{

    return NULL;
}

ImagePPM *cropPPM(ImagePPM *pImagePPM, int r1, int c1, int r2, int c2)
{

    return NULL;
}

void freeSpacePPM(ImagePPM *pImagePPM)
{

}
